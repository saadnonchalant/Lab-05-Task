#include <stdio.h>

int main(void) {
    int age;
    char day;
    double price;

    /* Sample prices - can be adjusted as needed */
    const double DISCOUNT_WEEKDAY = 150.0;
    const double DISCOUNT_WEEKEND = 200.0;
    const double REGULAR_WEEKDAY  = 300.0;
    const double REGULAR_WEEKEND  = 400.0;

    printf("Enter customer's age: ");
    scanf("%d", &age);

    printf("Enter day type ('W' for weekday, 'H' for weekend/holiday): ");
    scanf(" %c", &day);

    if (age < 12 || age > 60) {
        /* Discounted category */
        if (day == 'W' || day == 'w') {
            price = DISCOUNT_WEEKDAY;
        } else {
            if (day == 'H' || day == 'h') {
                price = DISCOUNT_WEEKEND;
            } else {
                printf("Invalid day entered.\n");
                return 1;
            }
        }
    } else {
        /* Regular category (age between 12 and 60 inclusive) */
        if (day == 'W' || day == 'w') {
            price = REGULAR_WEEKDAY;
        } else {
            if (day == 'H' || day == 'h') {
                price = REGULAR_WEEKEND;
            } else {
                printf("Invalid day entered.\n");
                return 1;
            }
        }
    }

    printf("Final ticket price: %.2f\n", price);

    return 0;
}
