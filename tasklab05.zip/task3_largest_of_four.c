#include <stdio.h>

int main(void) {
    double x, y, z, w, largest;

    printf("Enter four numbers X, Y, Z, W: ");
    scanf("%lf %lf %lf %lf", &x, &y, &z, &w);

    if (x > y) {
        if (x > z) {
            if (x > w) {
                largest = x;
            } else {
                largest = w;
            }
        } else {
            if (z > w) {
                largest = z;
            } else {
                largest = w;
            }
        }
    } else {
        if (y > z) {
            if (y > w) {
                largest = y;
            } else {
                largest = w;
            }
        } else {
            if (z > w) {
                largest = z;
            } else {
                largest = w;
            }
        }
    }

    printf("The largest value is: %.2f\n", largest);

    return 0;
}
