#include <stdio.h>

int main(void) {
    double a, b, c;

    printf("Enter three sides of the triangle (a b c): ");
    scanf("%lf %lf %lf", &a, &b, &c);

    /* Nested if-else to check validity */
    if (a + b > c) {
        if (a + c > b) {
            if (b + c > a) {
                /* Valid triangle - classify it */
                if (a == b) {
                    if (b == c) {
                        printf("Equilateral Triangle\n");
                    } else {
                        printf("Isosceles Triangle\n");
                    }
                } else {
                    if (a == c) {
                        printf("Isosceles Triangle\n");
                    } else {
                        if (b == c) {
                            printf("Isosceles Triangle\n");
                        } else {
                            printf("Scalene Triangle\n");
                        }
                    }
                }
            } else {
                printf("Not a valid triangle\n");
            }
        } else {
            printf("Not a valid triangle\n");
        }
    } else {
        printf("Not a valid triangle\n");
    }

    return 0;
}
