#include <stdio.h>

int main(void) {
    int marks;

    printf("Enter marks (0-100): ");
    scanf("%d", &marks);

    if (marks < 0 || marks > 100) {
        printf("Invalid marks entered.\n");
    } else {
        if (marks >= 90) {
            printf("Grade A\n");
            /* Nested if within Grade A branch */
            if (marks == 100) {
                printf("Perfect Score!\n");
            }
        } else {
            if (marks >= 75) {
                printf("Grade B\n");
            } else {
                if (marks >= 60) {
                    printf("Grade C\n");
                } else {
                    if (marks >= 40) {
                        printf("Grade D\n");
                    } else {
                        printf("Fail\n");
                    }
                }
            }
        }
    }

    return 0;
}
