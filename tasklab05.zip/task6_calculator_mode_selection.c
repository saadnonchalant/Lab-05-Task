#include <stdio.h>
#include <math.h>

int main(void) {
    char mode, op, subOp;
    double num1, num2, result;

    printf("Select mode ('1' for Basic Arithmetic, '2' for Power/Root): ");
    scanf(" %c", &mode);

    switch (mode) {
        case '1':
            printf("Enter operator (+, -, *, /): ");
            scanf(" %c", &op);

            printf("Enter two numbers: ");
            scanf("%lf %lf", &num1, &num2);

            switch (op) {
                case '+':
                    result = num1 + num2;
                    printf("Result: %.2f\n", result);
                    break;
                case '-':
                    result = num1 - num2;
                    printf("Result: %.2f\n", result);
                    break;
                case '*':
                    result = num1 * num2;
                    printf("Result: %.2f\n", result);
                    break;
                case '/':
                    if (num2 != 0) {
                        result = num1 / num2;
                        printf("Result: %.2f\n", result);
                    } else {
                        printf("Error: Division by zero.\n");
                    }
                    break;
                default:
                    printf("Invalid operator.\n");
            }
            break;

        case '2':
            printf("Enter sub-operation ('s' for square, 'r' for square root): ");
            scanf(" %c", &subOp);

            switch (subOp) {
                case 's':
                    printf("Enter a number: ");
                    scanf("%lf", &num1);
                    result = pow(num1, 2);
                    printf("Square: %.2f\n", result);
                    break;
                case 'r':
                    printf("Enter a number: ");
                    scanf("%lf", &num1);
                    if (num1 >= 0) {
                        result = sqrt(num1);
                        printf("Square Root: %.2f\n", result);
                    } else {
                        printf("Error: Cannot compute square root of a negative number.\n");
                    }
                    break;
                default:
                    printf("Invalid sub-operation.\n");
            }
            break;

        default:
            printf("Invalid mode selected.\n");
    }

    return 0;
}
