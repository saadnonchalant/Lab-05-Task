#include <stdio.h>

int main(void) {
    char accountType, transaction;

    printf("Select account type ('1' for Savings, '2' for Current): ");
    scanf(" %c", &accountType);

    switch (accountType) {
        case '1': /* Savings */
            printf("Select transaction ('1' Deposit, '2' Withdraw, '3' Check Balance): ");
            scanf(" %c", &transaction);

            switch (transaction) {
                case '1':
                    printf("Deposit made to Savings account.\n");
                    break;
                case '2':
                    printf("Withdrawal made from Savings account.\n");
                    break;
                case '3':
                    printf("Displaying balance for Savings account.\n");
                    break;
                default:
                    printf("Invalid transaction choice.\n");
            }
            break;

        case '2': /* Current */
            printf("Select transaction ('1' Deposit, '2' Withdraw, '3' Check Balance): ");
            scanf(" %c", &transaction);

            switch (transaction) {
                case '1':
                    printf("Deposit made to Current account.\n");
                    break;
                case '2':
                    printf("Withdrawal made from Current account.\n");
                    break;
                case '3':
                    printf("Displaying balance for Current account.\n");
                    break;
                default:
                    printf("Invalid transaction choice.\n");
            }
            break;

        default:
            printf("Invalid account type choice.\n");
    }

    return 0;
}
