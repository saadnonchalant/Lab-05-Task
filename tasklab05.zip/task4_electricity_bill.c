#include <stdio.h>

int main(void) {
    double units, bill;
    char type;

    printf("Enter units consumed: ");
    scanf("%lf", &units);

    printf("Enter connection type ('D' for domestic, 'C' for commercial): ");
    scanf(" %c", &type);

    if (units < 0) {
        printf("Invalid units entered.\n");
        return 1;
    }

    if (type == 'D' || type == 'd') {
        /* Domestic rates */
        if (units <= 100) {
            bill = units * 5.0;
        } else {
            if (units <= 300) {
                bill = 100 * 5.0 + (units - 100) * 7.5;
            } else {
                bill = 100 * 5.0 + 200 * 7.5 + (units - 300) * 10.0;
            }
        }
    } else {
        if (type == 'C' || type == 'c') {
            /* Commercial rates */
            if (units <= 100) {
                bill = units * 8.0;
            } else {
                if (units <= 300) {
                    bill = 100 * 8.0 + (units - 100) * 11.0;
                } else {
                    bill = 100 * 8.0 + 200 * 11.0 + (units - 300) * 15.0;
                }
            }
        } else {
            printf("Invalid connection type entered.\n");
            return 1;
        }
    }

    printf("Total electricity bill: %.2f\n", bill);

    return 0;
}
