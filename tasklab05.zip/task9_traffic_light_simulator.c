#include <stdio.h>

int main(void) {
    char light, pedestrian;

    printf("Enter traffic light color ('R', 'Y', 'G'): ");
    scanf(" %c", &light);

    switch (light) {
        case 'R':
        case 'r':
            printf("Enter pedestrian button status ('Y' for yes, 'N' for no): ");
            scanf(" %c", &pedestrian);

            switch (pedestrian) {
                case 'Y':
                case 'y':
                    printf("Action: Stop and cross.\n");
                    break;
                case 'N':
                case 'n':
                    printf("Action: Stop and wait.\n");
                    break;
                default:
                    printf("Invalid pedestrian button status.\n");
            }
            break;

        case 'Y':
        case 'y':
            printf("Action: Slow down, prepare to stop.\n");
            break;

        case 'G':
        case 'g':
            printf("Enter pedestrian button status ('Y' for yes, 'N' for no): ");
            scanf(" %c", &pedestrian);

            switch (pedestrian) {
                case 'Y':
                case 'y':
                    printf("Action: Go, but watch for pedestrians.\n");
                    break;
                case 'N':
                case 'n':
                    printf("Action: Go.\n");
                    break;
                default:
                    printf("Invalid pedestrian button status.\n");
            }
            break;

        default:
            printf("Invalid traffic light color.\n");
    }

    return 0;
}
