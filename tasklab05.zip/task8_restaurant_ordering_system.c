#include <stdio.h>

int main(void) {
    int category, item;

    printf("Choose a category:\n");
    printf("1. Beverages\n2. Main Course\n3. Desserts\n");
    printf("Enter choice: ");
    scanf("%d", &category);

    switch (category) {
        case 1: /* Beverages */
            printf("1. Coffee - $3.00\n2. Tea - $2.50\n3. Soda - $2.00\n");
            printf("Enter item choice: ");
            scanf("%d", &item);

            switch (item) {
                case 1:
                    printf("Coffee: $3.00\n");
                    break;
                case 2:
                    printf("Tea: $2.50\n");
                    break;
                case 3:
                    printf("Soda: $2.00\n");
                    break;
                default:
                    printf("Invalid item choice.\n");
            }
            break;

        case 2: /* Main Course */
            printf("1. Burger - $8.00\n2. Pasta - $10.00\n3. Steak - $15.00\n");
            printf("Enter item choice: ");
            scanf("%d", &item);

            switch (item) {
                case 1:
                    printf("Burger: $8.00\n");
                    break;
                case 2:
                    printf("Pasta: $10.00\n");
                    break;
                case 3:
                    printf("Steak: $15.00\n");
                    break;
                default:
                    printf("Invalid item choice.\n");
            }
            break;

        case 3: /* Desserts */
            printf("1. Ice Cream - $4.00\n2. Cake - $5.00\n3. Brownie - $4.50\n");
            printf("Enter item choice: ");
            scanf("%d", &item);

            switch (item) {
                case 1:
                    printf("Ice Cream: $4.00\n");
                    break;
                case 2:
                    printf("Cake: $5.00\n");
                    break;
                case 3:
                    printf("Brownie: $4.50\n");
                    break;
                default:
                    printf("Invalid item choice.\n");
            }
            break;

        default:
            printf("Invalid category choice.\n");
    }

    return 0;
}
